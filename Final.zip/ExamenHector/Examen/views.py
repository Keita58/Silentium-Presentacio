from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, redirect
from django.views import View

from Examen.models import Cartes


# Create your views here.
class Llistarcartes(LoginRequiredMixin, View):
    def get(self, request):
        if request.user.groups.filter(name="Rol1").exists():
            context={
                "cartes": list(Cartes.objects.all())
            }
            return render(request, "LlistarCartes.html", context)


class AfegirCarta(LoginRequiredMixin, View):
    def get(self, request):
        if request.user.groups.filter(name="Rol1").exists():
            return render(request, 'CrearCarta.html')

    def post(self, request):
        if request.user.groups.filter(name="Coordinador").exists():
            Cartes.objects.create(numero=request.POST.get('numero'),
                                       pal=request.POST.get('pal'))
            return redirect('carteslist')

class EsborrarCarta(LoginRequiredMixin, View):
    def get(self, request, id):
        if request.user.groups.filter(name="Rol1").exists():
            carta=Cartes.objects.get(idCartes=id)
            carta.delete()
            return redirect('carteslist')

class EditarCarta(LoginRequiredMixin, View):
    def get(self, request, id):
        if request.user.groups.filter(name="Rol1").exists():
            context={
                "carta":
                    Cartes.objects.get(idCartes=id)
            }
            return render(request, "EditarCarta.html", context)