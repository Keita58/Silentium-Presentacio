from django.contrib.auth.models import User
from django.db import models
from django.db.models import ManyToManyField


# Create your models here.

class Cartes(models.Model):
    idCartes=models.AutoField(primary_key=True)
    numero=models.IntegerField("numero", default=1)
    pal=models.CharField("pal", max_length=20)
    usuari=ManyToManyField(User, through="Cartesjugador")

    def __str__(self):
        return str(self.idCartes)

class Cartesjugador(models.Model):
    cartes=models.ForeignKey(Cartes, on_delete=models.CASCADE)
    jugador=models.ForeignKey(User, on_delete=models.CASCADE)